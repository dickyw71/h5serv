# jsontoh5 convertor
from .jsontoh5 import main as jsontoh5
